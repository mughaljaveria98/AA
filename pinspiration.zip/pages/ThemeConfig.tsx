
import React, { useState } from 'react';
import { BLOGGER_THEME_XML } from '../constants';
import { Copy, Check, Info, Settings, Layout, Search, Zap } from 'lucide-react';

const ThemeConfig: React.FC = () => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(BLOGGER_THEME_XML);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const seoTips = [
    { title: 'Semantic Headings', desc: 'Always use <h1> for post titles and <h2>/<h3> for subheaders inside posts.' },
    { title: 'Meta Descriptions', desc: 'In Blogger settings, enable search descriptions and write a unique one for every post.' },
    { title: 'Alt Text', desc: 'Every image should have descriptive alt text to help Google Image search index your site.' },
    { title: 'Custom URLs', desc: 'Edit the post permalink to be concise and include your primary keyword.' }
  ];

  return (
    <div className="max-w-5xl mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-serif font-bold text-gray-900 mb-4">Blogger Theme Engine</h1>
        <p className="text-gray-600 text-lg max-w-2xl mx-auto">
          Ready to launch your blog? Copy the custom XML theme code below and follow the instructions to upload it to your Google Blogger dashboard.
        </p>
      </div>

      {/* Code Area */}
      <div className="bg-gray-900 rounded-3xl overflow-hidden shadow-2xl mb-12 border-4 border-pink-900">
        <div className="px-6 py-4 bg-gray-800 border-b border-gray-700 flex justify-between items-center">
          <span className="text-pink-300 text-xs font-mono uppercase tracking-widest flex items-center gap-2">
            <Layout size={14} /> blogger-theme-pink.xml
          </span>
          <button 
            onClick={handleCopy}
            className="flex items-center gap-2 px-4 py-1.5 bg-pink-600 hover:bg-pink-700 text-white rounded-full text-xs font-bold transition-all transform active:scale-95"
          >
            {copied ? <><Check size={14} /> Copied</> : <><Copy size={14} /> Copy XML Code</>}
          </button>
        </div>
        <div className="p-6 h-96 overflow-y-auto custom-scrollbar">
          <pre className="text-pink-200 font-mono text-sm leading-relaxed">
            {BLOGGER_THEME_XML}
          </pre>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Instructions */}
        <section className="bg-white p-8 rounded-3xl border border-pink-50 shadow-sm">
          <h2 className="text-2xl font-serif font-bold mb-6 flex items-center gap-2">
            <Settings className="text-pink-600" /> How to Install
          </h2>
          <ol className="space-y-4 text-gray-700">
            <li className="flex gap-3">
              <span className="flex-shrink-0 w-6 h-6 bg-pink-100 text-pink-600 rounded-full flex items-center justify-center text-xs font-bold">1</span>
              <span>Go to your <b>Blogger Dashboard</b> &gt; <b>Theme</b>.</span>
            </li>
            <li className="flex gap-3">
              <span className="flex-shrink-0 w-6 h-6 bg-pink-100 text-pink-600 rounded-full flex items-center justify-center text-xs font-bold">2</span>
              <span>Click the arrow next to <b>Customize</b> and select <b>Edit HTML</b>.</span>
            </li>
            <li className="flex gap-3">
              <span className="flex-shrink-0 w-6 h-6 bg-pink-100 text-pink-600 rounded-full flex items-center justify-center text-xs font-bold">3</span>
              <span>Select all (Ctrl+A) and delete old code.</span>
            </li>
            <li className="flex gap-3">
              <span className="flex-shrink-0 w-6 h-6 bg-pink-100 text-pink-600 rounded-full flex items-center justify-center text-xs font-bold">4</span>
              <span>Paste the pink XML code and click <b>Save</b>.</span>
            </li>
          </ol>
        </section>

        {/* SEO Tips */}
        <section className="bg-white p-8 rounded-3xl border border-pink-50 shadow-sm">
          <h2 className="text-2xl font-serif font-bold mb-6 flex items-center gap-2">
            <Search className="text-pink-600" /> SEO Optimization
          </h2>
          <div className="space-y-6">
            {seoTips.map((tip) => (
              <div key={tip.title} className="flex gap-4">
                <div className="mt-1"><Zap size={18} className="text-pink-500" /></div>
                <div>
                  <h4 className="font-bold text-gray-900">{tip.title}</h4>
                  <p className="text-sm text-gray-600">{tip.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};

export default ThemeConfig;
