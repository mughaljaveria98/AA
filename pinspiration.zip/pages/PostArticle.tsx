
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Category } from '../types';
import { Image, Upload, CheckCircle } from 'lucide-react';

const PostArticle: React.FC = () => {
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState(Category.TECHNOLOGY);
  const [content, setContent] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const user = localStorage.getItem('user');
    if (!user) {
      navigate('/login');
    }
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
    setTimeout(() => {
      navigate('/');
    }, 2500);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      {isSubmitted ? (
        <div className="bg-white p-16 rounded-3xl border border-pink-100 shadow-xl text-center animate-scale-in">
          <div className="w-20 h-20 bg-green-500 text-white rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg shadow-green-100">
             <CheckCircle size={40} />
          </div>
          <h2 className="text-3xl font-serif font-bold text-gray-900 mb-2">Article Published!</h2>
          <p className="text-gray-600">Your insight has been posted to Pinspiration successfully.</p>
        </div>
      ) : (
        <div className="bg-white rounded-3xl border border-pink-100 shadow-xl overflow-hidden">
          <div className="p-8 md:p-12 border-b border-pink-50 bg-pink-50/10">
            <h1 className="text-3xl font-serif font-bold text-gray-900">Post Your Insight</h1>
            <p className="text-gray-500 mt-1">Share your thoughts with the global Pinspiration community.</p>
          </div>

          <form onSubmit={handleSubmit} className="p-8 md:p-12 space-y-8">
            <div className="space-y-2">
              <label className="text-sm font-bold text-gray-700">Article Title</label>
              <input required type="text" value={title} onChange={e => setTitle(e.target.value)} placeholder="The next big thing in..." className="w-full px-4 py-4 bg-pink-50/20 border border-pink-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-pink-500 text-xl font-serif" />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-700">Category</label>
                <select value={category} onChange={e => setCategory(e.target.value as Category)} className="w-full px-4 py-3 bg-pink-50/20 border border-pink-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-pink-500">
                  {Object.values(Category).map(cat => <option key={cat} value={cat}>{cat}</option>)}
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-700">Featured Image</label>
                <div className="w-full px-4 py-3 bg-pink-50/10 border border-dashed border-pink-200 rounded-xl flex items-center justify-center gap-2 text-pink-400 cursor-pointer hover:bg-pink-50 transition-colors">
                   <Image size={18} /> <span>Upload image (Max 5MB)</span>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-bold text-gray-700">Content</label>
              <textarea required value={content} onChange={e => setContent(e.target.value)} rows={12} placeholder="Write your story here..." className="w-full px-4 py-4 bg-pink-50/20 border border-pink-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-pink-500 leading-relaxed"></textarea>
            </div>

            <button type="submit" className="w-full py-4 bg-pink-600 text-white rounded-2xl font-bold hover:bg-pink-700 transition-all transform active:scale-[0.98] shadow-lg shadow-pink-100 flex items-center justify-center gap-2 text-lg">
              <Upload size={20} /> Publish Article
            </button>
          </form>
        </div>
      )}
    </div>
  );
};

export default PostArticle;
