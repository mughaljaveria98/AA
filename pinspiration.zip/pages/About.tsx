
import React from 'react';
import { Target, Users, ShieldCheck } from 'lucide-react';

const About: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 py-20">
      <div className="text-center mb-16">
        <h1 className="text-5xl font-serif font-bold text-gray-900 mb-6">Our Story</h1>
        <p className="text-xl text-gray-600 leading-relaxed">
          Pinspiration was founded with a single mission: to provide high-quality, verified, and engaging content for the curious minds of the digital era.
        </p>
      </div>

      <div className="rounded-3xl overflow-hidden mb-16 shadow-xl border-4 border-pink-50">
        <img src="https://picsum.photos/1200/600?nature" alt="Team working" className="w-full h-auto" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20">
        <div className="text-center p-6 bg-white rounded-2xl border border-pink-50">
          <div className="w-12 h-12 bg-pink-50 text-pink-600 rounded-xl flex items-center justify-center mx-auto mb-4">
            <Target size={24} />
          </div>
          <h3 className="font-bold mb-2">Our Mission</h3>
          <p className="text-sm text-gray-600">Democratizing information through expert analysis and simple explanations.</p>
        </div>
        <div className="text-center p-6 bg-white rounded-2xl border border-pink-50">
          <div className="w-12 h-12 bg-rose-50 text-rose-600 rounded-xl flex items-center justify-center mx-auto mb-4">
            <Users size={24} />
          </div>
          <h3 className="font-bold mb-2">Our Community</h3>
          <p className="text-sm text-gray-600">A global network of writers, researchers, and dedicated readers.</p>
        </div>
        <div className="text-center p-6 bg-white rounded-2xl border border-pink-50">
          <div className="w-12 h-12 bg-fuchsia-50 text-fuchsia-600 rounded-xl flex items-center justify-center mx-auto mb-4">
            <ShieldCheck size={24} />
          </div>
          <h3 className="font-bold mb-2">Our Ethics</h3>
          <p className="text-sm text-gray-600">Committed to journalistic integrity and data privacy for all users.</p>
        </div>
      </div>
    </div>
  );
};

export default About;
