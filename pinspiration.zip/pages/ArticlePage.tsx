
import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { MOCK_ARTICLES } from '../constants';
import Sidebar from '../components/Sidebar';
import { ChevronLeft, Share2, MessageCircle, Clock, Facebook, Twitter, Linkedin } from 'lucide-react';

const ArticlePage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const article = MOCK_ARTICLES.find(a => a.id === id);

  if (!article) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <h1 className="text-4xl font-bold mb-4">Article Not Found</h1>
        <Link to="/" className="text-pink-600 hover:underline">Return to Home</Link>
      </div>
    );
  }

  const shareUrl = window.location.href;
  const shareTitle = article.title;

  const handleShare = (platform: string) => {
    let url = '';
    switch (platform) {
      case 'facebook':
        url = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`;
        break;
      case 'twitter':
        url = `https://twitter.com/intent/tweet?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(shareTitle)}`;
        break;
      case 'linkedin':
        url = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareUrl)}`;
        break;
      default:
        break;
    }
    if (url) window.open(url, '_blank', 'width=600,height=400');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <Link to="/" className="inline-flex items-center gap-1 text-sm text-gray-500 hover:text-pink-600 mb-8 transition-colors group">
        <ChevronLeft size={16} className="group-hover:-translate-x-1 transition-transform" />
        Back to Feed
      </Link>

      <div className="flex flex-col lg:flex-row gap-12">
        <article className="flex-grow max-w-4xl">
          <div className="mb-6">
             <span className="px-3 py-1 bg-pink-100 text-pink-700 text-xs font-bold rounded-full uppercase tracking-widest">
                {article.category}
             </span>
          </div>
          
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-serif font-bold text-gray-900 leading-tight mb-6">
            {article.title}
          </h1>

          <div className="flex flex-wrap items-center gap-6 text-sm text-gray-500 mb-10 pb-6 border-b border-pink-50">
             <div className="flex items-center gap-2">
                <img src={`https://ui-avatars.com/api/?name=${article.author}&background=random`} alt={article.author} className="w-10 h-10 rounded-full" />
                <span className="font-bold text-gray-900">{article.author}</span>
             </div>
             <div className="flex items-center gap-1"><Clock size={16} /> 5 min read</div>
             <div className="flex items-center gap-1">Published on {article.date}</div>
          </div>

          <div className="rounded-3xl overflow-hidden mb-10 shadow-lg">
             <img src={article.imageUrl} alt={article.title} className="w-full h-auto" />
          </div>

          <div className="prose prose-lg max-w-none text-gray-700 leading-relaxed space-y-6">
            <p className="text-xl text-pink-900 font-medium italic border-l-4 border-pink-600 pl-4 py-2 bg-pink-50/50 rounded-r-lg">
              {article.excerpt}
            </p>
            <p>{article.content}</p>
            
            <h2 className="text-2xl font-serif font-bold text-gray-900 mt-12 mb-4">Deep Dive into the Topic</h2>
            <p>Curabitur pretium tincidunt lacus. Nulla gravida orci a odio. Nullam varius, turpis et commodo pharetra, est eros bibendum elit, nec luctus magna felis sollicitudin mauris.</p>
            
            <ul className="list-disc pl-6 space-y-2 marker:text-pink-600">
               <li>Critical infrastructure analysis</li>
               <li>Scalability considerations for the long term</li>
               <li>User-centric design principles</li>
            </ul>

            <div className="bg-pink-50/30 p-8 rounded-2xl mt-12 border border-pink-100">
              <h3 className="text-xl font-bold mb-2 text-pink-900">Key Takeaway</h3>
              <p className="text-pink-800/80">The transformation described here isn't just a shift in technology—it's a shift in how we perceive the boundaries between digital and physical interactions.</p>
            </div>
          </div>

          {/* Social Sharing Section */}
          <div className="mt-12 pt-8 border-t border-pink-100">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6">
              <div className="flex items-center gap-4">
                <span className="text-sm font-bold text-gray-900 uppercase tracking-widest">Share this story:</span>
                <div className="flex items-center gap-3">
                  <button 
                    onClick={() => handleShare('facebook')}
                    className="p-2.5 bg-[#1877F2] text-white rounded-full hover:opacity-90 transition-all hover:scale-110 shadow-lg shadow-blue-100" 
                    title="Share on Facebook"
                  >
                    <Facebook size={18} />
                  </button>
                  <button 
                    onClick={() => handleShare('twitter')}
                    className="p-2.5 bg-[#1DA1F2] text-white rounded-full hover:opacity-90 transition-all hover:scale-110 shadow-lg shadow-blue-50" 
                    title="Share on Twitter"
                  >
                    <Twitter size={18} />
                  </button>
                  <button 
                    onClick={() => handleShare('linkedin')}
                    className="p-2.5 bg-[#0A66C2] text-white rounded-full hover:opacity-90 transition-all hover:scale-110 shadow-lg shadow-blue-100" 
                    title="Share on LinkedIn"
                  >
                    <Linkedin size={18} />
                  </button>
                </div>
              </div>
              
              <div className="flex items-center gap-4">
                <button className="flex items-center gap-2 px-6 py-3 border border-pink-200 text-pink-600 rounded-2xl text-sm font-bold hover:bg-pink-50 transition-all active:scale-95">
                  <MessageCircle size={18} />
                  <span>12 Comments</span>
                </button>
              </div>
            </div>
          </div>
        </article>

        <aside className="lg:w-80 flex-shrink-0">
          <Sidebar />
        </aside>
      </div>
    </div>
  );
};

export default ArticlePage;
