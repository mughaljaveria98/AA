
import React, { useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { MOCK_ARTICLES } from '../constants';
import BlogCard from '../components/BlogCard';
import Sidebar from '../components/Sidebar';
import { Sparkles } from 'lucide-react';

const Home: React.FC = () => {
  const [searchParams] = useSearchParams();
  const categoryFilter = searchParams.get('cat');

  const filteredArticles = useMemo(() => {
    if (!categoryFilter) return MOCK_ARTICLES;
    return MOCK_ARTICLES.filter(a => a.category === categoryFilter);
  }, [categoryFilter]);

  const featuredPost = filteredArticles[0];
  const regularPosts = filteredArticles.slice(1);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <div className="flex flex-col lg:flex-row gap-8">
        {/* Main Content Area */}
        <div className="flex-grow space-y-12">
          
          {/* Header Title */}
          <div className="mb-8">
            <h2 className="text-4xl font-serif font-bold text-gray-900 flex items-center gap-2">
              <Sparkles className="text-pink-600" />
              {categoryFilter ? `${categoryFilter} Articles` : 'Featured Insights'}
            </h2>
            <div className="w-20 h-1 bg-pink-600 mt-2 rounded-full"></div>
          </div>

          {/* Hero Section (Featured Post) */}
          {featuredPost && !categoryFilter && (
            <div className="mb-12">
               <BlogCard article={featuredPost} featured />
            </div>
          )}

          {/* Grid Section */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {categoryFilter ? (
              filteredArticles.map(article => (
                <BlogCard key={article.id} article={article} />
              ))
            ) : (
              regularPosts.map(article => (
                <BlogCard key={article.id} article={article} />
              ))
            )}
          </div>

          {filteredArticles.length === 0 && (
            <div className="text-center py-20 bg-pink-50/30 rounded-2xl border-2 border-dashed border-pink-100">
               <p className="text-pink-900/50">No articles found in this category.</p>
            </div>
          )}
        </div>

        {/* Sidebar */}
        <div className="lg:w-80 flex-shrink-0">
          <Sidebar />
        </div>
      </div>
    </div>
  );
};

export default Home;
