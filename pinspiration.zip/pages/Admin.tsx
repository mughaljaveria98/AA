
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { MOCK_ARTICLES } from '../constants';
import { Article, UserRole } from '../types';
import { 
  LayoutDashboard, 
  FileText, 
  Users, 
  BarChart3, 
  Plus, 
  Trash2, 
  Edit3, 
  Eye, 
  Search,
  CheckCircle2,
  AlertCircle,
  X
} from 'lucide-react';

const Admin: React.FC = () => {
  const [articles, setArticles] = useState<Article[]>(MOCK_ARTICLES);
  const [editingArticle, setEditingArticle] = useState<Article | null>(null);
  const [notification, setNotification] = useState<{message: string, type: 'success' | 'error'} | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    if (!storedUser) {
      navigate('/login');
      return;
    }
    const user = JSON.parse(storedUser);
    if (user.role !== UserRole.ADMIN) {
      navigate('/');
    }
  }, [navigate]);

  const handleDelete = (id: string) => {
    setArticles(prev => prev.filter(art => art.id !== id));
    showNotification('Article deleted successfully', 'success');
  };

  const handleEdit = (article: Article) => {
    setEditingArticle(article);
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingArticle) {
      setArticles(prev => prev.map(art => art.id === editingArticle.id ? editingArticle : art));
      setEditingArticle(null);
      showNotification('Article updated successfully', 'success');
    }
  };

  const showNotification = (message: string, type: 'success' | 'error') => {
    setNotification({ message, type });
    setTimeout(() => setNotification(null), 3000);
  };

  const stats = [
    { label: 'Total Posts', value: articles.length, icon: FileText, color: 'bg-pink-100 text-pink-600' },
    { label: 'Total Views', value: '12.4K', icon: Eye, color: 'bg-rose-100 text-rose-600' },
    { label: 'Authors', value: '3', icon: Users, color: 'bg-fuchsia-100 text-fuchsia-600' },
    { label: 'Growth', value: '+14%', icon: BarChart3, color: 'bg-purple-100 text-purple-600' },
  ];

  return (
    <div className="min-h-screen bg-pink-50/20 p-4 md:p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* Header Section */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-serif font-bold text-gray-900 flex items-center gap-3">
              <LayoutDashboard className="text-pink-600" /> Admin Dashboard
            </h1>
            <p className="text-gray-500 mt-1">Full control over Pinspiration content.</p>
          </div>
          <button 
            onClick={() => navigate('/post-article')}
            className="flex items-center justify-center gap-2 px-6 py-3 bg-pink-600 text-white rounded-xl font-bold hover:bg-pink-700 transition-all shadow-lg shadow-pink-200"
          >
            <Plus size={20} /> Create New Post
          </button>
        </div>

        {/* Edit Modal */}
        {editingArticle && (
          <div className="fixed inset-0 bg-gray-900/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
            <div className="bg-white rounded-3xl w-full max-w-2xl overflow-hidden shadow-2xl animate-scale-in">
              <div className="p-6 border-b border-pink-50 flex items-center justify-between bg-pink-50/10">
                <h2 className="text-xl font-bold text-gray-900">Edit Article</h2>
                <button onClick={() => setEditingArticle(null)} className="p-2 hover:bg-pink-50 rounded-full text-gray-400"><X size={20}/></button>
              </div>
              <form onSubmit={handleSaveEdit} className="p-8 space-y-6 max-h-[70vh] overflow-y-auto custom-scrollbar">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-gray-500 uppercase tracking-wider">Title</label>
                  <input required value={editingArticle.title} onChange={e => setEditingArticle({...editingArticle, title: e.target.value})} className="w-full px-4 py-3 bg-pink-50/20 border border-pink-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-pink-500 font-serif" />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-gray-500 uppercase tracking-wider">Content Preview</label>
                  <textarea rows={5} required value={editingArticle.content} onChange={e => setEditingArticle({...editingArticle, content: e.target.value})} className="w-full px-4 py-3 bg-pink-50/20 border border-pink-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-pink-500" />
                </div>
                <div className="flex justify-end gap-3 mt-8">
                  <button type="button" onClick={() => setEditingArticle(null)} className="px-6 py-2.5 font-bold text-gray-500 hover:text-gray-700">Cancel</button>
                  <button type="submit" className="px-8 py-2.5 bg-pink-600 text-white rounded-xl font-bold hover:bg-pink-700 shadow-lg shadow-pink-100">Save Changes</button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Notification Toast */}
        {notification && (
          <div className={`fixed bottom-8 right-8 flex items-center gap-3 px-6 py-4 rounded-2xl shadow-2xl animate-slide-up z-[60] border ${
            notification.type === 'success' ? 'bg-white border-green-100 text-green-700' : 'bg-white border-red-100 text-red-700'
          }`}>
            {notification.type === 'success' ? <CheckCircle2 size={24} /> : <AlertCircle size={24} />}
            <span className="font-semibold">{notification.message}</span>
          </div>
        )}

        {/* Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat) => (
            <div key={stat.label} className="bg-white p-6 rounded-3xl border border-pink-100 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <div className={`p-3 rounded-2xl ${stat.color}`}>
                  <stat.icon size={24} />
                </div>
                <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">{stat.label}</span>
              </div>
              <div className="text-2xl font-bold text-gray-900">{stat.value}</div>
            </div>
          ))}
        </div>

        {/* Post Management Table */}
        <div className="bg-white rounded-3xl border border-pink-100 shadow-sm overflow-hidden">
          <div className="p-6 border-b border-pink-50 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <h2 className="text-xl font-serif font-bold text-gray-900">Manage Articles</h2>
            <div className="relative">
              <input 
                type="text" 
                placeholder="Search posts..." 
                className="pl-10 pr-4 py-2 bg-pink-50/50 border border-pink-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-pink-500 text-sm"
              />
              <Search className="absolute left-3 top-2.5 text-pink-300" size={16} />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-pink-50/30 text-xs font-bold text-pink-900 uppercase tracking-widest">
                <tr>
                  <th className="px-6 py-4">Article</th>
                  <th className="px-6 py-4">Category</th>
                  <th className="px-6 py-4">Author</th>
                  <th className="px-6 py-4">Date</th>
                  <th className="px-6 py-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-pink-50">
                {articles.map((article) => (
                  <tr key={article.id} className="hover:bg-pink-50/20 transition-colors group">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <img src={article.imageUrl} alt="" className="w-10 h-10 rounded-lg object-cover shadow-sm" />
                        <span className="font-semibold text-gray-900 max-w-xs truncate">{article.title}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="px-2 py-1 bg-pink-100 text-pink-600 text-[10px] font-bold rounded-full uppercase">
                        {article.category}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-600">{article.author}</td>
                    <td className="px-6 py-4 text-sm text-gray-500">{article.date}</td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button onClick={() => handleEdit(article)} className="p-2 text-gray-400 hover:text-pink-600 hover:bg-pink-100 rounded-lg transition-colors">
                          <Edit3 size={18} />
                        </button>
                        <button onClick={() => handleDelete(article.id)} className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors">
                          <Trash2 size={18} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Admin Branding */}
        <div className="bg-pink-900 p-8 rounded-3xl text-white flex flex-col md:flex-row items-center justify-between gap-6 overflow-hidden relative shadow-2xl">
          <div className="relative z-10">
            <h3 className="text-2xl font-serif font-bold mb-2">Pinspiration Authority</h3>
            <p className="text-pink-100/70 text-sm max-w-md">
              You are signed in as a Super Administrator. Every change made here directly affects the platform's core content.
            </p>
          </div>
          <div className="relative z-10 flex items-center gap-4 bg-white/10 p-4 rounded-2xl backdrop-blur-md">
             <div className="text-right">
                <div className="font-bold">Super Admin</div>
                <div className="text-xs text-pink-200">admin@pinspiration.media</div>
             </div>
             <img src="https://ui-avatars.com/api/?name=Admin&background=db2777&color=fff" alt="Profile" className="w-12 h-12 rounded-xl border border-white/20 shadow-xl" />
          </div>
          <div className="absolute top-0 right-0 w-64 h-64 bg-pink-800 rounded-full -translate-y-1/2 translate-x-1/2 opacity-20"></div>
        </div>

      </div>
    </div>
  );
};

export default Admin;
