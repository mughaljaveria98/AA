
import React, { useState } from 'react';
import { Send, MapPin, Phone, Mail } from 'lucide-react';

const Contact: React.FC = () => {
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-20">
      <div className="flex flex-col lg:flex-row gap-20">
        <div className="lg:w-1/3">
          <h1 className="text-5xl font-serif font-bold text-gray-900 mb-6">Get in Touch</h1>
          <p className="text-gray-600 mb-12">
            Have a question, feedback, or a story pitch? Reach out and we'll reply shortly.
          </p>

          <div className="space-y-8">
            <div className="flex items-start gap-4">
              <div className="p-3 bg-pink-50 text-pink-600 rounded-lg"><MapPin size={24} /></div>
              <div>
                <h4 className="font-bold">Headquarters</h4>
                <p className="text-gray-500 text-sm">123 Media Street, Suite 500<br />San Francisco, CA 94103</p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="p-3 bg-pink-50 text-pink-600 rounded-lg"><Phone size={24} /></div>
              <div>
                <h4 className="font-bold">Phone Support</h4>
                <p className="text-gray-500 text-sm">+1 (555) 123-4567</p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="p-3 bg-pink-50 text-pink-600 rounded-lg"><Mail size={24} /></div>
              <div>
                <h4 className="font-bold">Email Us</h4>
                <p className="text-gray-500 text-sm">hello@pinspiration.media<br />press@pinspiration.media</p>
              </div>
            </div>
          </div>
        </div>

        <div className="lg:w-2/3">
          {submitted ? (
            <div className="bg-pink-50 p-12 rounded-3xl border border-pink-100 text-center animate-fade-in">
              <div className="w-20 h-20 bg-pink-500 text-white rounded-full flex items-center justify-center mx-auto mb-6">
                 <Send size={32} />
              </div>
              <h2 className="text-3xl font-serif font-bold text-pink-900 mb-2">Message Sent!</h2>
              <p className="text-pink-700">We'll get back to you within 24 hours.</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="bg-white p-8 md:p-12 rounded-3xl border border-pink-50 shadow-xl space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-700">Full Name</label>
                  <input required type="text" className="w-full px-4 py-3 bg-pink-50/20 border border-pink-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-pink-500" placeholder="Jane Doe" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-700">Email Address</label>
                  <input required type="email" className="w-full px-4 py-3 bg-pink-50/20 border border-pink-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-pink-500" placeholder="jane@example.com" />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-700">Message</label>
                <textarea required rows={6} className="w-full px-4 py-3 bg-pink-50/20 border border-pink-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-pink-500" placeholder="Tell us more..."></textarea>
              </div>

              <button type="submit" className="w-full py-4 bg-pink-600 text-white rounded-xl font-bold hover:bg-pink-700 transition-all transform active:scale-[0.98] flex items-center justify-center gap-2">
                Send Message <Send size={18} />
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};

export default Contact;
