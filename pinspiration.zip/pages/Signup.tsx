
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Mail, Lock, User as UserIcon, ArrowRight } from 'lucide-react';
import { UserRole } from '../types';

const Signup: React.FC = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleSignup = (e: React.FormEvent) => {
    e.preventDefault();
    const mockUser = {
      id: Math.random().toString(36),
      name,
      email,
      role: UserRole.USER,
      avatar: `https://ui-avatars.com/api/?name=${name}&background=db2777&color=fff`
    };
    localStorage.setItem('user', JSON.stringify(mockUser));
    navigate('/');
  };

  return (
    <div className="min-h-[calc(100vh-64px)] flex items-center justify-center bg-pink-50/30 p-4">
      <div className="w-full max-w-md bg-white rounded-3xl shadow-xl border border-pink-100 overflow-hidden">
        <div className="p-8 md:p-10">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-serif font-bold text-gray-900 mb-2">Create Account</h1>
            <p className="text-gray-500 text-sm">Join the Pinspiration community today</p>
          </div>

          <form onSubmit={handleSignup} className="space-y-5">
            <div className="space-y-1.5">
              <label className="text-sm font-bold text-gray-700 ml-1">Full Name</label>
              <div className="relative">
                <UserIcon className="absolute left-4 top-3.5 text-pink-300" size={18} />
                <input required type="text" value={name} onChange={e => setName(e.target.value)} placeholder="Jane Doe" className="w-full pl-11 pr-4 py-3 bg-pink-50/20 border border-pink-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-pink-500" />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-sm font-bold text-gray-700 ml-1">Email Address</label>
              <div className="relative">
                <Mail className="absolute left-4 top-3.5 text-pink-300" size={18} />
                <input required type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="jane@example.com" className="w-full pl-11 pr-4 py-3 bg-pink-50/20 border border-pink-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-pink-500" />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-sm font-bold text-gray-700 ml-1">Password</label>
              <div className="relative">
                <Lock className="absolute left-4 top-3.5 text-pink-300" size={18} />
                <input required type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••" className="w-full pl-11 pr-4 py-3 bg-pink-50/20 border border-pink-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-pink-500" />
              </div>
            </div>

            <button type="submit" className="w-full py-4 bg-pink-600 text-white rounded-xl font-bold hover:bg-pink-700 transition-all transform active:scale-[0.98] flex items-center justify-center gap-2 shadow-lg shadow-pink-100">
              Create Account <ArrowRight size={18} />
            </button>
          </form>

          <div className="relative my-8">
            <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-pink-100"></div></div>
            <div className="relative flex justify-center text-xs uppercase"><span className="bg-white px-2 text-gray-400 font-semibold tracking-wider">Or continue with</span></div>
          </div>

          <button className="w-full py-3.5 border border-pink-100 rounded-xl font-bold text-gray-700 hover:bg-pink-50 transition-all flex items-center justify-center gap-3">
            <img src="https://www.google.com/favicon.ico" alt="Google" className="w-5 h-5" />
            Continue with Gmail
          </button>
        </div>

        <div className="p-6 bg-pink-50/50 border-t border-pink-100 text-center text-sm">
          <p className="text-gray-600">Already have an account? <Link to="/login" className="text-pink-600 font-bold hover:underline">Log in here</Link></p>
        </div>
      </div>
    </div>
  );
};

export default Signup;
