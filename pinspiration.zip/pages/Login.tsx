
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Mail, Lock, ArrowRight, Github } from 'lucide-react';
import { UserRole } from '../types';

const Login: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Demo Logic
    setTimeout(() => {
      const role = email.toLowerCase().includes('admin') ? UserRole.ADMIN : UserRole.USER;
      const mockUser = {
        id: 'u1',
        name: email.split('@')[0],
        email: email,
        role: role,
        avatar: `https://ui-avatars.com/api/?name=${email}&background=db2777&color=fff`
      };
      
      localStorage.setItem('user', JSON.stringify(mockUser));
      setIsLoading(false);
      navigate(role === UserRole.ADMIN ? '/admin' : '/');
    }, 1000);
  };

  const handleGmailLogin = () => {
    setIsLoading(true);
    setTimeout(() => {
       const mockUser = {
        id: 'u-google',
        name: 'Google User',
        email: 'user@gmail.com',
        role: UserRole.USER,
        avatar: 'https://www.gstatic.com/images/branding/product/2x/avatar_anonymous_120x120dp.png'
      };
      localStorage.setItem('user', JSON.stringify(mockUser));
      setIsLoading(false);
      navigate('/');
    }, 1000);
  };

  return (
    <div className="min-h-[calc(100vh-64px)] flex items-center justify-center bg-pink-50/30 p-4">
      <div className="w-full max-w-md bg-white rounded-3xl shadow-xl border border-pink-100 overflow-hidden">
        <div className="p-8 md:p-10">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-serif font-bold text-gray-900 mb-2">Welcome Back</h1>
            <p className="text-gray-500 text-sm">Log in to Pinspiration to manage your insights</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-5">
            <div className="space-y-1.5">
              <label className="text-sm font-bold text-gray-700 ml-1">Email Address</label>
              <div className="relative">
                <Mail className="absolute left-4 top-3.5 text-pink-300" size={18} />
                <input 
                  required 
                  type="email" 
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="admin@pinspiration.media" 
                  className="w-full pl-11 pr-4 py-3 bg-pink-50/20 border border-pink-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-pink-500 transition-all" 
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-sm font-bold text-gray-700 ml-1 flex justify-between">
                Password
                <span className="text-pink-600 font-medium hover:underline cursor-pointer">Forgot?</span>
              </label>
              <div className="relative">
                <Lock className="absolute left-4 top-3.5 text-pink-300" size={18} />
                <input 
                  required 
                  type="password" 
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••" 
                  className="w-full pl-11 pr-4 py-3 bg-pink-50/20 border border-pink-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-pink-500 transition-all" 
                />
              </div>
            </div>

            <button 
              type="submit" 
              disabled={isLoading}
              className="w-full py-4 bg-pink-600 text-white rounded-xl font-bold hover:bg-pink-700 transition-all transform active:scale-[0.98] flex items-center justify-center gap-2 shadow-lg shadow-pink-100 disabled:opacity-50"
            >
              {isLoading ? 'Logging in...' : <><span className="mr-1">Login</span> <ArrowRight size={18} /></>}
            </button>
          </form>

          <div className="relative my-8">
            <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-pink-100"></div></div>
            <div className="relative flex justify-center text-xs uppercase"><span className="bg-white px-2 text-gray-400 font-semibold tracking-wider">Or continue with</span></div>
          </div>

          <button 
            onClick={handleGmailLogin}
            className="w-full py-3.5 border border-pink-100 rounded-xl font-bold text-gray-700 hover:bg-pink-50 transition-all flex items-center justify-center gap-3"
          >
            <img src="https://www.google.com/favicon.ico" alt="Google" className="w-5 h-5" />
            Continue with Gmail
          </button>
        </div>

        <div className="p-6 bg-pink-50/50 border-t border-pink-100 text-center text-sm">
          <p className="text-gray-600">Don't have an account? <Link to="/signup" className="text-pink-600 font-bold hover:underline">Create an account</Link></p>
        </div>
      </div>
    </div>
  );
};

export default Login;
