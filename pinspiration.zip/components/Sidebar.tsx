
import React from 'react';
import { Category } from '../types';
import { Mail, TrendingUp, Facebook, Twitter, Instagram } from 'lucide-react';

const Sidebar: React.FC = () => {
  const categories = Object.values(Category);

  return (
    <aside className="space-y-8">
      {/* Search Widget - Mock */}
      <div className="bg-white p-6 rounded-2xl border border-pink-50 shadow-sm">
        <h4 className="font-serif font-bold text-lg mb-4">Search Articles</h4>
        <div className="relative">
          <input 
            type="text" 
            placeholder="Search keywords..." 
            className="w-full pl-4 pr-10 py-2 bg-pink-50/30 border border-pink-100 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500 text-sm"
          />
          <button className="absolute right-3 top-2.5 text-pink-400">
            <TrendingUp size={16} />
          </button>
        </div>
      </div>

      {/* Newsletter Widget */}
      <div className="bg-pink-600 p-6 rounded-2xl text-white shadow-lg shadow-pink-200">
        <div className="flex items-center gap-3 mb-4">
          <div className="p-2 bg-white/20 rounded-lg">
            <Mail size={20} />
          </div>
          <h4 className="font-bold text-lg">Newsletter</h4>
        </div>
        <p className="text-pink-100 text-sm mb-4">Get the latest news and insights delivered to your inbox every Monday.</p>
        <input 
          type="email" 
          placeholder="your@email.com" 
          className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg mb-3 text-white placeholder:text-pink-200 focus:outline-none focus:bg-white/20 text-sm"
        />
        <button className="w-full py-2 bg-white text-pink-600 font-bold rounded-lg hover:bg-pink-50 transition-colors text-sm">
          Subscribe Now
        </button>
      </div>

      {/* Categories Widget */}
      <div className="bg-white p-6 rounded-2xl border border-pink-50 shadow-sm">
        <h4 className="font-serif font-bold text-lg mb-4">Categories</h4>
        <div className="flex flex-wrap gap-2">
          {categories.map((cat) => (
            <a 
              key={cat} 
              href={`#?cat=${cat}`}
              className="px-3 py-1.5 bg-pink-50/50 text-gray-700 text-sm rounded-lg border border-pink-50 hover:bg-pink-100 hover:text-pink-700 hover:border-pink-200 transition-all"
            >
              {cat}
            </a>
          ))}
        </div>
      </div>

      {/* Social Widget */}
      <div className="bg-white p-6 rounded-2xl border border-pink-50 shadow-sm text-center">
        <h4 className="font-serif font-bold text-lg mb-4">Follow Us</h4>
        <div className="flex justify-center gap-4">
          <button className="p-3 bg-pink-50 text-pink-600 rounded-full hover:bg-pink-100 transition-colors"><Facebook size={20}/></button>
          <button className="p-3 bg-pink-50 text-pink-600 rounded-full hover:bg-pink-100 transition-colors"><Twitter size={20}/></button>
          <button className="p-3 bg-pink-50 text-pink-600 rounded-full hover:bg-pink-100 transition-colors"><Instagram size={20}/></button>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
