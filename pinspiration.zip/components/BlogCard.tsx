
import React from 'react';
import { Link } from 'react-router-dom';
import { Article } from '../types';
import { Calendar, User, ArrowRight } from 'lucide-react';

interface BlogCardProps {
  article: Article;
  featured?: boolean;
}

const BlogCard: React.FC<BlogCardProps> = ({ article, featured = false }) => {
  return (
    <div className={`group bg-white rounded-2xl overflow-hidden border border-pink-50 shadow-sm hover:shadow-xl transition-all duration-300 ${featured ? 'md:flex' : ''}`}>
      <div className={`${featured ? 'md:w-1/2' : 'h-48'} overflow-hidden`}>
        <img
          src={article.imageUrl}
          alt={article.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
      </div>
      <div className={`p-6 ${featured ? 'md:w-1/2 flex flex-col justify-center' : ''}`}>
        <div className="flex items-center gap-2 mb-3">
          <span className="px-3 py-1 bg-pink-50 text-pink-600 text-xs font-bold rounded-full uppercase tracking-wider">
            {article.category}
          </span>
        </div>
        <h3 className={`font-serif font-bold text-gray-900 group-hover:text-pink-600 transition-colors leading-tight mb-3 ${featured ? 'text-3xl' : 'text-xl'}`}>
          <Link to={`/article/${article.id}`}>{article.title}</Link>
        </h3>
        <p className="text-gray-600 text-sm mb-4 line-clamp-2">
          {article.excerpt}
        </p>
        <div className="flex items-center justify-between mt-auto">
          <div className="flex items-center gap-4 text-xs text-gray-500">
            <span className="flex items-center gap-1"><User size={14} /> {article.author}</span>
            <span className="flex items-center gap-1"><Calendar size={14} /> {article.date}</span>
          </div>
          <Link to={`/article/${article.id}`} className="text-pink-600 hover:text-pink-700 font-semibold text-sm flex items-center gap-1">
            Read <ArrowRight size={14} />
          </Link>
        </div>
      </div>
    </div>
  );
};

export default BlogCard;
