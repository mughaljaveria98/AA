
import React, { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Menu, X, Search, Code, Shield, User as UserIcon, LogOut, PlusCircle } from 'lucide-react';
import { User, UserRole } from '../types';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
  }, [location]);

  const handleLogout = () => {
    localStorage.removeItem('user');
    setUser(null);
    navigate('/');
  };

  const navItems = [
    { label: 'Home', path: '/' },
    { label: 'Technology', path: '/?cat=Technology' },
    { label: 'Education', path: '/?cat=Education' },
    { label: 'Health', path: '/?cat=Health' },
    { label: 'About', path: '/about' },
    { label: 'Contact', path: '/contact' },
  ];

  if (user?.role === UserRole.ADMIN) {
    navItems.push({ label: 'Admin', path: '/admin' });
  }

  const isActive = (path: string) => {
    if (path.includes('?cat=')) {
        return location.search.includes(path.split('=')[1]);
    }
    return location.pathname === path && location.search === '';
  };

  return (
    <header className="fixed top-0 left-0 right-0 bg-white/80 backdrop-blur-md z-50 border-b border-pink-100 shadow-sm">
      <div className="absolute top-0 left-0 right-0 h-0.5 animate-shimmer"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 group shrink-0">
            <div className="w-9 h-9 bg-pink-600 rounded-lg flex items-center justify-center text-white group-hover:bg-pink-700 transition-all duration-300 group-hover:rotate-6 group-hover:scale-105 shadow-md shadow-pink-200">
              <span className="font-bold text-lg italic">P</span>
            </div>
            <span className="text-xl font-serif font-bold text-gray-900 tracking-tight hidden sm:block group-hover:text-pink-600 transition-colors">Pinspiration</span>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex items-center gap-5">
            {navItems.map((item) => (
              <Link
                key={item.label}
                to={item.path}
                className={`text-sm font-semibold transition-colors nav-underline ${
                  isActive(item.path) 
                    ? 'text-pink-600 nav-underline-active' 
                    : 'text-gray-600 hover:text-pink-600'
                }`}
              >
                {item.label}
              </Link>
            ))}
          </nav>

          {/* Actions */}
          <div className="flex items-center gap-3">
            <Link 
              to="/post-article" 
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 bg-pink-50 text-pink-700 rounded-full text-xs font-bold hover:bg-pink-100 transition-all border border-pink-200"
            >
              <PlusCircle size={14} />
              Post Article
            </Link>

            {user ? (
              <div className="flex items-center gap-3 ml-2 pl-3 border-l border-gray-100">
                <div className="hidden md:block text-right">
                  <p className="text-xs font-bold text-gray-900 leading-none">{user.name}</p>
                  <p className="text-[10px] text-gray-400 capitalize">{user.role}</p>
                </div>
                <button onClick={handleLogout} className="p-2 text-gray-400 hover:text-pink-600 hover:bg-pink-50 rounded-full transition-colors" title="Logout">
                  <LogOut size={18} />
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2 ml-2">
                <Link to="/login" className="text-sm font-semibold text-gray-600 hover:text-pink-600 px-3 py-2 transition-colors">Login</Link>
                <Link to="/signup" className="hidden sm:block text-sm font-bold bg-pink-600 text-white px-4 py-2 rounded-full hover:bg-pink-700 transition-all shadow-md shadow-pink-100">Sign Up</Link>
              </div>
            )}

            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="lg:hidden p-2 text-gray-500 hover:bg-pink-50 rounded-lg transition-colors"
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="lg:hidden bg-white border-b border-pink-100 animate-slide-down">
          <div className="px-4 pt-2 pb-6 space-y-1">
            {navItems.map((item) => (
              <Link
                key={item.label}
                to={item.path}
                onClick={() => setIsMenuOpen(false)}
                className={`block px-3 py-3 rounded-md text-base font-medium transition-colors ${
                  isActive(item.path) ? 'bg-pink-50 text-pink-600' : 'text-gray-700 hover:bg-pink-50 hover:text-pink-600'
                }`}
              >
                {item.label}
              </Link>
            ))}
            <div className="pt-4 flex flex-col gap-2">
               <Link to="/post-article" onClick={() => setIsMenuOpen(false)} className="w-full py-3 bg-pink-50 text-pink-700 rounded-xl font-bold text-center border border-pink-200">Post Article</Link>
               {!user && <Link to="/signup" onClick={() => setIsMenuOpen(false)} className="w-full py-3 bg-pink-600 text-white rounded-xl font-bold text-center">Sign Up</Link>}
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;
