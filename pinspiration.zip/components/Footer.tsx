
import React from 'react';
import { Link } from 'react-router-dom';

const Footer: React.FC = () => {
  return (
    <footer className="bg-pink-950 text-pink-100 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
          <div className="col-span-1 md:col-span-2">
            <Link to="/" className="flex items-center gap-2 mb-6">
              <div className="w-8 h-8 bg-pink-600 rounded flex items-center justify-center text-white">
                <span className="font-bold text-lg">P</span>
              </div>
              <span className="text-xl font-serif font-bold text-white tracking-tight">Pinspiration</span>
            </Link>
            <p className="text-pink-200/70 max-w-sm">
              We provide deep insights into technology, education, and health. Our goal is to empower readers with accurate news and actionable tutorials.
            </p>
          </div>
          
          <div>
            <h5 className="text-white font-bold mb-4">Quick Links</h5>
            <ul className="space-y-2 text-sm">
              <li><Link to="/" className="hover:text-pink-400">Homepage</Link></li>
              <li><Link to="/about" className="hover:text-pink-400">About Us</Link></li>
              <li><Link to="/contact" className="hover:text-pink-400">Contact</Link></li>
              <li><Link to="/theme-config" className="hover:text-pink-400">Developer Tools</Link></li>
            </ul>
          </div>

          <div>
            <h5 className="text-white font-bold mb-4">Connect</h5>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="hover:text-pink-400">Twitter (X)</a></li>
              <li><a href="#" className="hover:text-pink-400">LinkedIn</a></li>
              <li><a href="#" className="hover:text-pink-400">GitHub</a></li>
              <li><a href="#" className="hover:text-pink-400">Support</a></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-pink-900 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-xs">
          <p>&copy; 2024 Pinspiration Media. All rights reserved.</p>
          <div className="flex gap-6">
            <a href="#" className="hover:text-white">Privacy Policy</a>
            <a href="#" className="hover:text-white">Terms of Service</a>
            <a href="#" className="hover:text-white">Cookies</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
